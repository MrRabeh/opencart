<?php
class ControllerProductCategory extends Controller {
	public function index() {
		$this->load->language('product/category');

		$this->load->model('catalog/category');

		$this->load->model('catalog/product');

		$this->load->model('tool/image');

		if (isset($this->request->get['filter'])) {
			$filter = $this->request->get['filter'];
		} else {
			$filter = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'p.sort_order';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		if (isset($this->request->get['limit'])) {
			$limit = (int)$this->request->get['limit'];
		} else {
			$limit = $this->config->get('theme_' . $this->config->get('config_theme') . '_product_limit');
		}


				$data['text_empty'] = $this->language->get('text_empty');
			
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		if (isset($this->request->get['path'])) {
			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$path = '';

			$parts = explode('_', (string)$this->request->get['path']);

			$category_id = (int)array_pop($parts);

			foreach ($parts as $path_id) {
				if (!$path) {
					$path = (int)$path_id;
				} else {
					$path .= '_' . (int)$path_id;
				}

				$category_info = $this->model_catalog_category->getCategory($path_id);

				if ($category_info) {
					$data['breadcrumbs'][] = array(
						'text' => $category_info['name'],
						'href' => $this->url->link('product/category', 'path=' . $path . $url)
					);
				}
			}
		} else {
			$category_id = 0;
		}

		$category_info = $this->model_catalog_category->getCategory($category_id);

		if ($category_info) {
			$this->document->setTitle($category_info['meta_title']);
			$this->document->setDescription($category_info['meta_description']);
			$this->document->setKeywords($category_info['meta_keyword']);


            /* Plaza Category Configuration */
            $store_id = $this->config->get('config_store_id');

            /* Catalog Mode */
            if(isset($this->config->get('module_ptcontrolpanel_category_price')[$store_id])) {
                $data['show_cate_price'] = (int) $this->config->get('module_ptcontrolpanel_category_price')[$store_id];
            } else {
                $data['show_cate_price'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_category_cart')[$store_id])) {
                $data['show_cate_cart'] = (int) $this->config->get('module_ptcontrolpanel_category_cart')[$store_id];
            } else {
                $data['show_cate_cart'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_category_wishlist')[$store_id])) {
                $data['show_cate_wishlist'] = (int) $this->config->get('module_ptcontrolpanel_category_wishlist')[$store_id];
            } else {
                $data['show_cate_wishlist'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_category_compare')[$store_id])) {
                $data['show_cate_compare'] = (int) $this->config->get('module_ptcontrolpanel_category_compare')[$store_id];
            } else {
                $data['show_cate_compare'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_category_prodes')[$store_id])) {
                $data['show_cate_prodes'] = (int) $this->config->get('module_ptcontrolpanel_category_prodes')[$store_id];
            } else {
                $data['show_cate_prodes'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_category_label')[$store_id])) {
                $data['show_cate_label'] = (int) $this->config->get('module_ptcontrolpanel_category_label')[$store_id];
            } else {
                $data['show_cate_label'] = 0;
            }

            /* Category Settings */
            if(isset($this->config->get('module_ptcontrolpanel_category_image')[$store_id])) {
                $data['show_cate_img'] = (int) $this->config->get('module_ptcontrolpanel_category_image')[$store_id];
            } else {
                $data['show_cate_img'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_category_description')[$store_id])) {
                $data['show_cate_des'] = (int) $this->config->get('module_ptcontrolpanel_category_description')[$store_id];
            } else {
                $data['show_cate_des'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_sub_category')[$store_id])) {
                $data['show_cate_sub'] = (int) $this->config->get('module_ptcontrolpanel_sub_category')[$store_id];
            } else {
                $data['show_cate_sub'] = 0;
            }

            if(isset($this->config->get('module_ptcontrolpanel_use_filter')[$store_id])) {
                $data['use_filter'] = (int) $this->config->get('module_ptcontrolpanel_use_filter')[$store_id];
            } else {
                $data['use_filter'] = 0;
            }

            if (!empty($_SERVER['HTTPS'])) {
                // SSL connection
                $common_url = str_replace('http://', 'https://', $this->config->get('config_url'));
            } else {
                $common_url = $this->config->get('config_url');
            }

            $data['pt_sorts'] = array();

            $data['pt_limits'] = array();

            if($data['use_filter']) {
                
				
				$this->document->addStyle('catalog/view/javascript/jquery/css/jquery-ui.css');
				if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/plaza/category/filter.css')) {
                    $this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/plaza/category/filter.css');
                } else {
                    $this->document->addStyle('catalog/view/theme/default/stylesheet/plaza/category/filter.css');
                }
				$this->document->addScript('catalog/view/javascript/jquery/jquery-ui.js');	
                $this->document->addScript('catalog/view/javascript/plaza/category/filter.js');

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_default'),
                    'value' => 'p.sort_order-ASC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=p.sort_order&order=ASC' . $url
                );

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_name_asc'),
                    'value' => 'pd.name-ASC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=pd.name&order=ASC' . $url
                );

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_name_desc'),
                    'value' => 'pd.name-DESC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=pd.name&order=DESC' . $url
                );

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_price_asc'),
                    'value' => 'p.price-ASC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=p.price&order=ASC' . $url
                );

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_price_desc'),
                    'value' => 'p.price-DESC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=p.price&order=DESC' . $url
                );

                if ($this->config->get('config_review_status')) {
                    $data['pt_sorts'][] = array(
                        'text'  => $this->language->get('text_rating_desc'),
                        'value' => 'rating-DESC',
                        'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=rating&order=DESC' . $url
                    );

                    $data['pt_sorts'][] = array(
                        'text'  => $this->language->get('text_rating_asc'),
                        'value' => 'rating-ASC',
                        'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=rating&order=ASC' . $url
                    );
                }

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_model_asc'),
                    'value' => 'p.model-ASC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=p.model&order=ASC' . $url
                );

                $data['pt_sorts'][] = array(
                    'text'  => $this->language->get('text_model_desc'),
                    'value' => 'p.model-DESC',
                    'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . '&sort=p.model&order=DESC' . $url
                );

                $data['pt_limits'] = array();

                $limits = array_unique(array($this->config->get('theme_' . $this->config->get('config_theme') . '_product_limit'), 25, 50, 75, 100));

                sort($limits);

                foreach($limits as $value) {
                    $data['pt_limits'][] = array(
                        'text'  => $value,
                        'value' => $value,
                        'href'  => $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . $url . '&limit=' . $value
                    );
                }

                if(isset($this->config->get('module_ptcontrolpanel_loader_img')[$store_id])) {
                    $data['loader_img'] = $common_url . 'image/' . $this->config->get('module_ptcontrolpanel_loader_img')[$store_id];
                } else {
                    $data['loader_img'] = $common_url . 'image/plaza/ajax-loader.gif';;
                }
            }

            if(isset($this->config->get('module_ptcontrolpanel_cate_quickview')[$store_id])) {
	            $data['use_quick_view'] = (int) $this->config->get('module_ptcontrolpanel_cate_quickview')[$store_id];
	        } else {
	            $data['use_quick_view'] = 0;
	        }

	        if(isset($this->config->get('module_ptcontrolpanel_img_effect')[$store_id])) {
                $data['image_effect'] = $this->config->get('module_ptcontrolpanel_img_effect')[$store_id];
            } else {
                $data['image_effect'] = false;
            }

            if($data['image_effect'] == 'swatches') {
                $this->document->addScript('catalog/view/javascript/plaza/swatches/swatches.js');
            }

            if(isset($this->config->get('module_ptcontrolpanel_advance_view')[$store_id])) {
                $data['use_advance_view'] = (int) $this->config->get('module_ptcontrolpanel_advance_view')[$store_id];
            } else {
                $data['use_advance_view'] = 0;
            }

            if($data['use_advance_view']) {
                $this->document->addScript('catalog/view/javascript/plaza/category/grid.js');
            }

            if(isset($this->config->get('module_ptcontrolpanel_default_view')[$store_id])) {
                $data['advance_default_view'] = $this->config->get('module_ptcontrolpanel_default_view')[$store_id];
            } else {
                $data['advance_default_view'] = false;
            }

            if(isset($this->config->get('module_ptcontrolpanel_product_row')[$store_id])) {
                $data['product_p_row'] = $this->config->get('module_ptcontrolpanel_product_row')[$store_id];
            } else {
                $data['product_p_row'] = false;
            }
			$new_results = $this->model_catalog_product->getLatestProducts(10);
            
			$data['heading_title'] = $category_info['name'];

			$data['text_compare'] = sprintf($this->language->get('text_compare'), (isset($this->session->data['compare']) ? count($this->session->data['compare']) : 0));

			// Set the last category breadcrumb
			$data['breadcrumbs'][] = array(
				'text' => $category_info['name'],
				'href' => $this->url->link('product/category', 'path=' . $this->request->get['path'])
			);

			if ($category_info['image']) {
				$data['thumb'] = $this->model_tool_image->resize($category_info['image'], $this->config->get('theme_' . $this->config->get('config_theme') . '_image_category_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_category_height'));
			} else {
				$data['thumb'] = '';
			}

			$data['description'] = html_entity_decode($category_info['description'], ENT_QUOTES, 'UTF-8');
			$data['compare'] = $this->url->link('product/compare');

			$url = '';

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['categories'] = array();

			$results = $this->model_catalog_category->getCategories($category_id);

			foreach ($results as $result) {
				$filter_data = array(
					'filter_category_id'  => $result['category_id'],
					'filter_sub_category' => true
				);

				$data['categories'][] = array(
					'name' => $result['name'] . ($this->config->get('config_product_count') ? ' (' . $this->model_catalog_product->getTotalProducts($filter_data) . ')' : ''),
					'href' => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '_' . $result['category_id'] . $url)
				);
			}

			$data['products'] = array();

			$filter_data = array(
				'filter_category_id' => $category_id,
				'filter_filter'      => $filter,
				'sort'               => $sort,
				'order'              => $order,
				'start'              => ($page - 1) * $limit,
				'limit'              => $limit
			);

			$product_total = $this->model_catalog_product->getTotalProducts($filter_data);

			$results = $this->model_catalog_product->getProducts($filter_data);

			foreach ($results as $result) {
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_height'));
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_height'));
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = (int)$result['rating'];
				} else {
					$rating = false;
				}


                if($data['image_effect'] == 'hover') {
                    $this->load->model('plaza/rotateimage');

                    $product_rotate_image = $this->model_plaza_rotateimage->getProductRotateImage($result['product_id']);

                    if($product_rotate_image) {
                        $rotate_image = $this->model_tool_image->resize($product_rotate_image, $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_height'));
                    } else {
                        $rotate_image = false;
                    }
                } else {
                    $rotate_image = false;
                }

                $swatches_images = array();

                $options = array();

                if($data['image_effect'] == 'swatches') {
                    $data['icon_swatches_width'] = $this->config->get('module_ptcontrolpanel_cate_swatches_width')[$store_id];
                    $data['icon_swatches_height'] = $this->config->get('module_ptcontrolpanel_cate_swatches_height')[$store_id];

                    $this->load->model('plaza/swatches');

                    $images = $this->model_catalog_product->getProductImages($result['product_id']);

                    $is_swatches = false;

                    foreach ($images as $img) {
                        if ($img['product_option_value_id']) {
                            $image_option_id = $this->model_plaza_swatches->getOptionIdByProductOptionValueId($img['product_option_value_id']);

                            if($image_option_id == $this->config->get('module_ptcontrolpanel_swatches_option')[$store_id]) {
                                $is_swatches = true;

                                $swatches_images[] = array(
                                    'product_option_value_id' => $img['product_option_value_id'],
                                    'image' => $this->model_tool_image->resize($img['image'], $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_height'))
                                );
                            }
                        }
                    }

                    if($is_swatches) {
                        foreach ($this->model_catalog_product->getProductOptions($result['product_id']) as $option) {
                            if($option['option_id'] == $this->config->get('module_ptcontrolpanel_swatches_option')[$store_id]) {
                                $product_option_value_data = array();

                                foreach ($option['product_option_value'] as $option_value) {
                                    if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                                        $product_option_value_data[] = array(
                                            'product_option_value_id' => $option_value['product_option_value_id'],
                                            'option_value_id'         => $option_value['option_value_id'],
                                            'name'                    => $option_value['name'],
                                            'image'                   => $this->model_tool_image->resize($option_value['image'], $data['icon_swatches_width'], $data['icon_swatches_height']),
                                        );
                                    }
                                }

                                $options[] = array(
                                    'product_option_id'    => $option['product_option_id'],
                                    'product_option_value' => $product_option_value_data,
                                    'option_id'            => $option['option_id'],
                                    'name'                 => $option['name'],
                                    'type'                 => $option['type'],
                                    'value'                => $option['value'],
                                );
                            }
                        }
                    }
                }
				$is_new = false;
				if ($new_results) {
					foreach($new_results as $new_r) {
						if($result['product_id'] == $new_r['product_id']) {
							$is_new = true;
						}
					}
				}
            

				if ($result['quantity'] <= 0) {
					$stock = $result['stock_status'];
				} elseif ($this->config->get('config_stock_display')) {
					$stock = $result['quantity'];
				} else {
					$stock = $this->language->get('text_instock');
				}
			
				$data['products'][] = array(

					'stock'		=> $stock,
					'quantity'      => (int) $result['quantity'],
            

                    'options' => $options,
                    'swatches_images' => $swatches_images,
                    'rotate_image' => $rotate_image,
					'is_new'        => $is_new,
            
					'product_id'  => $result['product_id'],
					'thumb'       => $image,
					'name'        => $result['name'],
					'description' => utf8_substr(trim(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8'))), 0, $this->config->get('theme_' . $this->config->get('config_theme') . '_product_description_length')) . '..',
					'price'       => $price,
					'special'     => $special,
					'tax'         => $tax,
					'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
					'rating'      => $result['rating'],

				// Add manufacturer
					'manufacturer' => $result['manufacturer'],
					'manufacturer_href' => $this->url->link('product/manufacturer/info', 'manufacturer_id=' . $result['manufacturer_id']),
				// End Add manufacturer
			
					'href'        => $this->url->link('product/product', 'path=' . $this->request->get['path'] . '&product_id=' . $result['product_id'] . $url)
				);
			}

			$url = '';

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['sorts'] = array();

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_default'),
				'value' => 'p.sort_order-ASC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=p.sort_order&order=ASC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_name_asc'),
				'value' => 'pd.name-ASC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=pd.name&order=ASC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_name_desc'),
				'value' => 'pd.name-DESC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=pd.name&order=DESC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_price_asc'),
				'value' => 'p.price-ASC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=p.price&order=ASC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_price_desc'),
				'value' => 'p.price-DESC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=p.price&order=DESC' . $url)
			);

			if ($this->config->get('config_review_status')) {
				$data['sorts'][] = array(
					'text'  => $this->language->get('text_rating_desc'),
					'value' => 'rating-DESC',
					'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=rating&order=DESC' . $url)
				);

				$data['sorts'][] = array(
					'text'  => $this->language->get('text_rating_asc'),
					'value' => 'rating-ASC',
					'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=rating&order=ASC' . $url)
				);
			}

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_model_asc'),
				'value' => 'p.model-ASC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=p.model&order=ASC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_model_desc'),
				'value' => 'p.model-DESC',
				'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort=p.model&order=DESC' . $url)
			);

			$url = '';

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			$data['limits'] = array();

			$limits = array_unique(array($this->config->get('theme_' . $this->config->get('config_theme') . '_product_limit'), 25, 50, 75, 100));

			sort($limits);

			foreach($limits as $value) {
				$data['limits'][] = array(
					'text'  => $value,
					'value' => $value,
					'href'  => $this->url->link('product/category', 'path=' . $this->request->get['path'] . $url . '&limit=' . $value)
				);
			}

			$url = '';

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}


            $pt_pagination = new Pagination();
            $pt_pagination->total = $product_total;
            $pt_pagination->page = $page;
            $pt_pagination->limit = $limit;
            $pt_pagination->url = $common_url . 'index.php?route=plaza/filter/category&path=' . $category_id . $url . '&page={page}';

            $data['pt_pagination'] = $pt_pagination->render();
            
			$pagination = new Pagination();
			$pagination->total = $product_total;
			$pagination->page = $page;
			$pagination->limit = $limit;
			$pagination->url = $this->url->link('product/category', 'path=' . $this->request->get['path'] . $url . '&page={page}');

			$data['pagination'] = $pagination->render();

			$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($product_total - $limit)) ? $product_total : ((($page - 1) * $limit) + $limit), $product_total, ceil($product_total / $limit));

			// http://googlewebmastercentral.blogspot.com/2011/09/pagination-with-relnext-and-relprev.html
			if ($page == 1) {
			    $this->document->addLink($this->url->link('product/category', 'path=' . $category_info['category_id']), 'canonical');
			} else {
				$this->document->addLink($this->url->link('product/category', 'path=' . $category_info['category_id'] . '&page='. $page), 'canonical');
			}
			
			if ($page > 1) {
			    $this->document->addLink($this->url->link('product/category', 'path=' . $category_info['category_id'] . (($page - 2) ? '&page='. ($page - 1) : '')), 'prev');
			}

			if ($limit && ceil($product_total / $limit) > $page) {
			    $this->document->addLink($this->url->link('product/category', 'path=' . $category_info['category_id'] . '&page='. ($page + 1)), 'next');
			}

			$data['sort'] = $sort;
			$data['order'] = $order;
			$data['limit'] = $limit;

			$data['continue'] = $this->url->link('common/home');

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			$this->response->setOutput($this->load->view('product/category', $data));
		} else {
			$url = '';

			if (isset($this->request->get['path'])) {
				$url .= '&path=' . $this->request->get['path'];
			}

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_error'),
				'href' => $this->url->link('product/category', $url)
			);

			$this->document->setTitle($this->language->get('text_error'));

			$data['continue'] = $this->url->link('common/home');

			$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			$this->response->setOutput($this->load->view('error/not_found', $data));
		}
	}
}
