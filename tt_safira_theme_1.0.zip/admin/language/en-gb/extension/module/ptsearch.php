<?php
// Heading
$_['heading_title']         = '<b style="color: #eb5202;"><i><i class="s fa fa-search"></i> Plaza Ajax Search</i></b>';
$_['page_title']            = 'Plaza Ajax Search';

// Text
$_['text_extension']        = 'Extensions';
$_['text_edit']             = 'Edit Plaza Ajax Search Module';
$_['text_success']          = 'Success: You have modified this module!';

// Entry
$_['entry_status']          = 'Status';
$_['entry_ajax_enabled']    = 'Ajax Search';
$_['entry_product_image']   = 'Product Image';
$_['entry_product_price']   = 'Product Price';

//Error
$_['error_permission']      = 'Warning: You do not have permission to modify this module!';