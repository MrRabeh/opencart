<?php
$_['text_theme_dashboard']  = "PlazaThemes Dashboard";
$_['text_dashboard_menu']   = "Dashboard Menu";
$_['text_control_panel']    = "Control Panel";
$_['text_theme_module']     = "Modules";
$_['text_special_category'] = "Special of Categories";
$_['text_ultimate_menu']    = 'Ultimate Menu';
$_['text_blog']             = "Blog";
$_['text_posts']            = "Posts";
$_['text_posts_list']       = "Categories";
$_['text_blog_setting']     = "Page Settings";
$_['text_testimonial']      = "Testimonials";
$_['text_slider']           = "Sliders Management";
$_['text_newsletter']       = "Newsletter Emails";