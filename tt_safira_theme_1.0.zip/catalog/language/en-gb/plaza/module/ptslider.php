<?php
$_['text_link_button'] = 'Read more';