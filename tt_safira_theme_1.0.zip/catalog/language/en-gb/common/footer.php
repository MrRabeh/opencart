<?php
// Text
$_['text_information']  = 'Information';
$_['text_service']      = 'Customer Service';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contact Us';
$_['text_return']       = 'Returns';
$_['text_sitemap']      = 'Site Map';
$_['text_manufacturer'] = 'Brands';
$_['text_voucher']      = 'Gift Certificates';
$_['text_affiliate']    = 'Affiliate';
$_['text_special']      = 'Specials';
$_['text_account']      = 'My Account';
$_['text_order']        = 'Order History';
$_['text_wishlist']     = 'Wish List';
$_['text_newsletter']   = 'Newsletter';
$_['text_description_footer']   = 'We are a team of designers and developers that create high quality Magento, Prestashop, Opencart.';
$_['text_address']   = 'Address:';
$_['text_email']   = 'Email:';
$_['text_phone']   = 'Call us:';
$_['text_signup_newsletter']   = 'Sign up newsletter';
// Edit by Plazathemes
$_['text_twitter_widget']   = 'twitter widget';
$_['text_powered']      = 'Copyright  © 2020 <a href="http://plazathemes.com">Plazathemes</a>. All Rights Reserved.Design by <a href="http://plazathemes.com">Plazathemes.com</a>';